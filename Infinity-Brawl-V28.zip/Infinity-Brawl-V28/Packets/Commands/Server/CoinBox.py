from Database.DatabaseManager import DataBase
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage

from Utils.Writer import Writer
class CoinBox(Writer):
	def __init__(self, client, player, count):
	       super().__init__(client)
	       self.id = 24111
	       self.player = player
	       self.count = count
	def encode(self):
	 	self.writeVint(203) # CommandID
	 	self.writeVint(0)   # Unknown
	 	self.writeVint(1)   # Multipler
	 	self.writeVint(2) # BoxID
	 	self.writeVint(1)
	 	DataBase.replaceValue(self, 'gold', self.count)
	 	self.writeVint(self.count)#count
	 	self.writeVint(0)
	 	self.writeVint(7)#ID
	 	self.writeVint(0)
	 	self.writeVint(0)
	 	self.writeVint(0)
	 	self.writeVint(0)
	 	for x in range(13):
	 		self.writeVint(0)