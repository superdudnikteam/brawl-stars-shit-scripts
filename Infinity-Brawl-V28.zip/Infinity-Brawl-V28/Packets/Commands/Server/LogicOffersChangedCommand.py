from Database.DatabaseManager import DataBase
from Utils.Writer import Writer
from Logic.Shop import Shop

class LogicOffersChangedCommand(Writer):

	def __init__(self, client, player):
		super().__init__(client)
		self.id = 24111
		self.player = player

	def encode(self):
		self.writeVint(211) # Command ID
		
		Shop.EncodeShopOffers(self)