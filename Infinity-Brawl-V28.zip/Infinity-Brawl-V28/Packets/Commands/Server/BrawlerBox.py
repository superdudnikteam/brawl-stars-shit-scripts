from Database.DatabaseManager import DataBase
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage

from Utils.Writer import Writer
class BrawlerBox(Writer):
    def __init__(self, client, player, brawlerID):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.brawlerID = brawlerID
    def encode(self):
    	   self.writeVint(203) # CommandID
    	   self.writeVint(0)   # Unknown
    	   self.writeVint(1)   # Multipler
    	   self.writeVint(2) # BoxID
    	   self.writeVint(1)
    	   self.writeVint(1)
    	   try:
    	   	self.player.BrawlersUnlockedState[str(self.brawlerID)] = 1
    	   	self.writeScId(16, self.brawlerID)#brawler
    	   	DataBase.replaceValue(self, 'UnlockedBrawlers', self.player.BrawlersUnlockedState)
    	   except:
    	   	self.writeScId(16, 0)#shelly xxx bruh
    	   self.writeVint(1) # Reward ID
    	   self.writeVint(0) # CsvID 29
    	   self.writeVint(0) # CsvID 52
    	   self.writeVint(0) # CsvID 23
    	   self.writeVint(0)
    	   for i in range(13):
    	    	self.writeVint(0)
         	