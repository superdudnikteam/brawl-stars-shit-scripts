from Database.DatabaseManager import DataBase
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
import random
from Utils.Writer import Writer

class LogicAddedGemsForClubMessage(Writer):
	def __init__(self, client, player, count):
	       super().__init__(client)
	       self.id = 24111
	       self.player = player
	       self.count = count
	       
	def encode(self):
	 	self.writeVint(203) # CommandID
	 	self.writeVint(0)   # Unknown
	 	self.writeVint(1)   # Multipler
	 	self.writeVint(100) # BoxID
	 	self.writeVint(1) #Reward Count
	 	
	 	self.writeVint(10) # Value ~ Count
	 	self.writeVint(0) # CsvID ?
	 	self.writeVint(8) # Reward ID
	 	self.writeScId(0, 0) # CsvID 29
	 	self.writeVint(0) # CsvID 52
	 	self.writeVint(0) # CsvID 23
	 	self.writeVint(0) # ?
	 	
	 	self.writeVint(1)
	 	self.writeVint(0)
	 	self.writeVint(11)
	 	for i in range(13):
	 		self.writeVint(0)