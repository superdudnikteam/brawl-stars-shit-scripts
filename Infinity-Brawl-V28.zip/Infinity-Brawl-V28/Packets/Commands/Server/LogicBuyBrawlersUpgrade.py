from Database.DatabaseManager import DataBase
from Utils.Writer import Writer

class LogicBuyBrawlersUpgrade(Writer):

    def __init__(self, client, player, boxtype, reqID, count):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.reward = boxtype
        self.reqID = reqID
        self.count = count

    def encode(self):
    	print("24111 send")
    	self.writeVint(203)
    	self.writeVint(0)
    	self.writeVint(1)
    	self.writeVint(100)
    	#box header end
    	
    	#reward info start
    	self.writeVint(1)
    	self.writeVint(self.count)
    	if self.reward == 6:
    		self.player.brawlers_upgradium[str(self.reqID)]= self.count
    		DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)
    		self.writeScId(16,self.reqID)
    	else:
    		self.writeVint(0)
    	self.writeVint(self.reward)
    	if self.reward == 9:
    		self.writeScId(29, self.reqID)
    	else:
    		self.writeVint(0)
    	self.writeVint(0)
    	self.writeVint(0)
    	self.writeVint(0)
    	for i in range(13):
    		self.writeVint(0)