from Utils.Reader import BSMessageReader
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamChat import TeamChatMsg

class TeamDudkaChat(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
    def decode(self):
    	pass
    def process(self):
    	TeamChatMsg(self.client, self.player).send()