from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamGameStartingMessage import TeamGameStartingMessage

from Utils.Reader import BSMessageReader

class SetReadyTeam(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
      #  self.invites = []
        self.isReady = self.read_Vint()

    def process(self):
        self.player.isReady = self.isReady
        TeamGameroomDataMessage(self.client, self.player).send()