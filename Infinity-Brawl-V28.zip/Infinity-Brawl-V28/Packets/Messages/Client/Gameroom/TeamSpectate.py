from ByteStream.Reader import Reader
from Protocol.Messages.Server.TeamMessage import TeamMessage
from Protocol.Messages.Server.Team.TeamError import TeamError

class TeamSpectate(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.roomsID = self.readVInt()

    def process(self, db):
        if self.player.inTeam == False:
        	self.player.roomType = 0
        	self.player.roomsID = self.roomsID
        	self.player.isReady = False
        	self.player.inTeam = True
        	TeamMessage(self.client, self.player).send()
        	
        else:
        	TeamError(self.client, self.player).send()
        	