from Utils.Reader import BSMessageReader
from Packets.Messages.Server.Gameroom.TeamStream import TeamStream
from Database.DatabaseManager import DataBase

class TeamBrawler(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        print(initial_bytes)
    def decode(self):
	    print(self.read_Vint)
	    self.pin = self.read_Vint()
		 
    def process(self):
        self.player.pin = self.pin
        print(self.pin)
        self.player.ctick += 1
        TeamStream(self.client, self.player).send()