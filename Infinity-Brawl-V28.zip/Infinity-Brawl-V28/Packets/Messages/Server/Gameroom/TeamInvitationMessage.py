from Utils.Writer import Writer


class TeamInviteMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 14365
        self.player = player

    def encode(self):
        self.writeVint(1) # Count
        self.writeInt(0)
        self.writeInt(1)
        self.writeInt(0)
        self.writeInt(2)
        for x in range(6):
        	self.writeString()
        self.writeInt(6974) # Trophies
        for x in range(4):
        	self.writeInt(0)

        bool1 = True
        self.writeBoolean(bool1)
        if bool1:
        	self.writeInt(0)
        	self.writeInt(3)
        	self.writeInt(0)
        	self.writeString()
        	for x in range(2):
        		self.writeInt(0)

        self.writeString()
        self.writeInt(0)
        bool2 = True
        self.writeBoolean(bool2)
        if bool2:
        	self.writeString("оцекок лох")
        	self.writeVint(100)
        	self.writeVint(28000049)
        	self.writeVint(43000004)
        	self.writeVint(43000004)