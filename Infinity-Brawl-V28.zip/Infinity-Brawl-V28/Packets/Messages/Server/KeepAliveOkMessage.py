from Utils.Writer import Writer

from Packets.Commands.Server.LogicOffersChangedCommand import LogicOffersChangedCommand
import json

from Utils.OfferGenerator import OfferGenerator

from Database.DatabaseManager import DataBase

class KeepAliveOkMessage(Writer):

	def __init__(self, client, player):
		super().__init__(client)
		self.id = 20108
		self.player = player

	def encode(self):
		try:
			for i in range(1):
				brawlers1337 = []
				dudka = self.player.BrawlersUnlockedState
				upgrades = self.player.Brawler_level
				pps = self.player.brawlers_upgradium
				for brawler in dudka:
					if int(dudka[brawler]) == 1 and int(upgrades[brawler]) != 8:
						brawlers1337.append(int(brawler))
				generated = []
				generated.append(OfferGenerator.generateDailyGift(brawlers1337) )
				offs = OfferGenerator.generateOffersList(brawlers1337)
				for offer in offs:
					generated.append(offer)
				generated = str(generated).replace("'", "\"")
				self.player.shopniki = json.dumps(generated)
			
				DataBase.replaceValue(self, "shopniki", generated)
				#dodo.close()
				
				print(self.player.shopniki)
			
			LogicOffersChangedCommand(self.client, self.player).send()
		except Exception as e:
			print("dodo пицца доставка", e)