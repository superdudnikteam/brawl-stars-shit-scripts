from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import random
import time
import psutil

class LobbyInfoMessage(Writer):

    def __init__(self, client, player, count):
        super().__init__(client)
        self.id = 23457
        self.player = player
        self.count = count

    def encode(self):
        self.writeVint(1)
        self.writeString(f"Infinity Brawl\ntg: @infinity_servers\nenv: {self.player.env}\n{time.asctime()}\nRAM: {psutil.virtual_memory().percent}%\nCPU: {psutil.cpu_percent()}%\nPlayers Online: {self.count}\n0-1\nServer: game.infinitybrawl.com via lo\nLatencyTestResult: 1\nR:6974|127.0.0.1:0000|A:0 Q:228 -> 1 msecs\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")

        self.writeVint(1) # array
        for x in range(0):
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)
