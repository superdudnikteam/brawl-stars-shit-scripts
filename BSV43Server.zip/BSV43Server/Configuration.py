
# DisableNagle: reduce delay and improve performance between client and server BUT require more power #

settings = {
    "DisableNagle": True,
    "PrintEnabled": True,
    "UseContentUpdater": False,
    "Theme": 42,
    "SkinPack": 16,
    "DoubleTokenEvent": False,
    "GoldRushEvent": True,
    "Maintance": False,
    "MaintanceTime": 1200,
    "UpdateURL": "https://t.me/fightingbrawl/164",
    "Proxy": False,
    "DumpPacket": False,
    "Blacklist": [24109],
    "DumpMajor": 43
}
